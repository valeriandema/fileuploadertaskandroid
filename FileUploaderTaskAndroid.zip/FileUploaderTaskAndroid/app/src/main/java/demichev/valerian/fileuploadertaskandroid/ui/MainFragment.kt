package demichev.valerian.fileuploadertaskandroid.ui

import android.app.Activity.RESULT_OK
import android.content.ActivityNotFoundException
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import demichev.valerian.fileuploadertaskandroid.R
import demichev.valerian.fileuploadertaskandroid.network.ProgressRequestBody
import demichev.valerian.fileuploadertaskandroid.network.UploadCallbacks
import demichev.valerian.fileuploadertaskandroid.utils.MAX_QUANTITY_OF_FILES
import demichev.valerian.fileuploadertaskandroid.utils.MAX_SIZE_OF_FILE
import demichev.valerian.fileuploadertaskandroid.utils.getMimeType
import demichev.valerian.fileuploadertaskandroid.view_model.FileUploaderViewModel
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream

class MainFragment : Fragment(), CoroutineScope by MainScope() {

    /*
    Kotlin is chosen because client's requirements

    Libraries that are used in the project:
    1. Dagger2 - dependency injection

    2. Retrofit2 - Rest Client
    2.1 Gson - serialisation network response
    2.2 OkHttpClient - make HTTPS queries

    3. Coroutines - kotlin's extension for handling threads
    4. Lifecycle viewmodel - viewmodel that is able to outlive screen rotation in case it should be needed
    5. Material - all layouts and widgets are from material design library with cornerFamily - cut

    What this app does:
    it allows to pick up images from storage (10 at once) and to upload them to server.
    Before uploading pictures they are compressed a little
    Each image sends in separate thread that can be restarted in case it fails or cancelled
    */

    companion object {
        fun newInstance() = MainFragment()
        private const val PICK_FILE_RESULT_CODE = 1221
    }
    private val viewModel  by lazy { ViewModelProvider(this).get(FileUploaderViewModel::class.java) }
    private var bsdUploadFiles: BottomSheetDialog? = null
    private var bottomSheetLayout: ViewGroup? = null
    private lateinit var llContent: LinearLayout
    private lateinit var progressBar: ProgressBar
    private var results: Pair<Int, Int> = Pair(0,0)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.main_fragment, container, false)

        llContent = v.findViewById(R.id.llContent)
        progressBar = v.findViewById(R.id.progressBar)

        v.findViewById<ViewGroup>(R.id.clMain).setOnClickListener {
            openFileChooserIntent()
        }

        return v
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        if (savedInstanceState == null)
            openFileChooserIntent()
    }

    private fun openFileChooserIntent() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        try {
            startActivityForResult(intent, PICK_FILE_RESULT_CODE)
        } catch (e: ActivityNotFoundException) {
            Log.e("tag", "No activity can handle picking a file. Showing alternatives.")
        }
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_RESULT_CODE && resultCode == RESULT_OK) {
            resetUploadViews()
            viewModel.isJobsCleared.postValue(false)

            if (null != data) {
                if (null != data.clipData) {
                    if (data.clipData!!.itemCount > MAX_QUANTITY_OF_FILES) {
                        openDateTypeMenu({
                            handleIntentData(data)
                        }, {
                            openFileChooserIntent()
                        })
                    } else {
                        handleIntentData(data)
                    }
                } else {
                    val uri = data.data!!
                    handleUri(uri)
                }
            }
        }
    }

    private fun handleIntentData(data: Intent) {
        val list = mutableListOf<Uri>()

        val untilVal = if (data.clipData!!.itemCount > MAX_QUANTITY_OF_FILES) MAX_QUANTITY_OF_FILES else data.clipData!!.itemCount
        for (i in 0 until untilVal) {
            val uri = data.clipData!!.getItemAt(i).uri!!
            list.add(uri)
        }
        list.forEach {
            handleUri(it)
        }
    }

    private fun openDateTypeMenu(continueBtn: () -> Unit, tryAgainBtn: () -> Unit) {
        val bottomSheetDialog = BottomSheetDialog(activity!!, R.style.SheetDialog)
        val layout: View =
            layoutInflater.inflate(R.layout.bottom_sheet_amount_exceed, llContent, false)
        val btnPostedDate: MaterialButton = layout.findViewById(R.id.btnContinue)
        btnPostedDate.setOnClickListener {
            continueBtn.invoke()
            bottomSheetDialog.dismiss()
        }

        val btnTryAgain: MaterialButton = layout.findViewById(R.id.btnTryAgain)
        btnTryAgain.setOnClickListener {
            tryAgainBtn.invoke()
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.setContentView(layout)
        bottomSheetDialog.show()
    }

    private fun handleUri(uri: Uri) = launch {
        if (!progressBar.isShown) {
            progressBar.visibility = View.VISIBLE
        }
        val pair = withContext(Dispatchers.Default) {
            val file = File(activity!!.cacheDir, getFileName(uri))

            val bitmap = getBitmap(uri)
            val size = writeBitmapToFile(bitmap, file, uri)

            val hashMap = mapOf("name" to file.name)
            val jsonRequest= JSONObject(hashMap).toString()
                .toRequestBody("application/json".toMediaTypeOrNull())

            if (viewModel.isJobsCleared.value == true)
                this.cancel()

            Pair(jsonRequest, Pair(size, file))
        }

        val item = inflateItem()
        openUploadFilesDialog(item)

        if (progressBar.isShown) {
            progressBar.visibility = View.GONE
        }

        doQuery(pair, uri, item)
    }

    private fun openUploadFilesDialog(item: ViewGroup) {
        if (bsdUploadFiles == null) {
            bsdUploadFiles = BottomSheetDialog(activity!!, R.style.SheetDialog)

            bsdUploadFiles?.setCancelable(false)
            bottomSheetLayout =
                layoutInflater.inflate(R.layout.bottom_sheet_upload_files, llContent, false) as ViewGroup

            bottomSheetLayout?.let {
                bsdUploadFiles?.setContentView(it)
            }

            bottomSheetLayout?.findViewById<ViewGroup>(R.id.llListFiles)?.addView(item)
        } else {
            bottomSheetLayout?.findViewById<ViewGroup>(R.id.llListFiles)?.addView(item)
        }

        bsdUploadFiles?.show()

        bottomSheetLayout?.findViewById<ImageView>(R.id.ivCloseDialog)?.setOnClickListener {
            viewModel.isJobsCleared.postValue(true)
            resetUploadViews()
            dismissUploadDialog()
        }
    }

    private fun dismissUploadDialog() {
        viewModel.clearAllJobs()
        bsdUploadFiles?.dismiss()
    }

    private fun getFileName(uri: Uri): String {
        var cursor: Cursor? = null
        var fileName = ""
        try {
            cursor = context?.contentResolver?.query(uri, arrayOf(MediaStore.Images.ImageColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                fileName = cursor.getString(cursor.getColumnIndex(MediaStore.Images.ImageColumns.DISPLAY_NAME))
            }
        } finally {
            cursor?.close()
        }
        return fileName
    }

    private fun doQuery(pair: Pair<RequestBody, Pair<Int, File>>, uri: Uri, item: ViewGroup) {
        val progressBar = item.findViewById<ProgressBar>(R.id.progressBar)
        val tvFile = item.findViewById<TextView>(R.id.tvFile)
        val ivAction = item.findViewById<ImageView>(R.id.ivAction)

        if (pair.second.first > MAX_SIZE_OF_FILE) {
            tvFile.text = getString(R.string.file_size_exceed, pair.second.second.name, pair.second.first)
            progressBar.visibility = View.GONE
            ivAction.setImageResource(R.drawable.fail)
            item.findViewById<TextView>(R.id.tvError).visibility = View.VISIBLE
        } else {
            tvFile.text = pair.second.second.name
            bottomSheetLayout?.findViewById<TextView>(R.id.tvStatus)?.text = getString(R.string.processing_uploads)

            if (results.second > 0) {
                bottomSheetLayout?.findViewById<TextView>(R.id.tvFilesUpload)?.text = getString(R.string.failed_files, results.second)
            } else {
                bottomSheetLayout?.findViewById<TextView>(R.id.tvFilesUpload)?.text =
                    getString(R.string.uploaded_files, results.first, getUploadCounter())
            }

            val cancelJob = viewModel.uploadFiles(prepareFilePart(pair.second.second, uri, progressBar), pair.first) { success ->
                    if (success == null) {
                        bottomSheetLayout?.findViewById<TextView>(R.id.tvStatus)?.text = getString(R.string.upload_complete)
                        updateHeader(getUploadCounter())
                        if (results.second > 0) {
                            bottomSheetLayout?.findViewById<TextView>(R.id.tvFilesUpload)?.text = getString(R.string.failed_files, results.second)
                        }
                    } else if (success) {
                        results = results.copy(first = results.first.inc())
                        progressBar.visibility = View.GONE
                        ivAction.setImageResource(R.drawable.ok)
                        updateHeader(results.first)
                    } else {
                        results = results.copy(second = results.second.inc())

                        progressBar.visibility = View.GONE
                        ivAction.setImageResource(R.drawable.fail)

                        val tvRetry = item.findViewById<TextView>(R.id.tvRetry)
                        tvRetry.visibility = View.VISIBLE
                        tvRetry.setOnClickListener {
                            results = results.copy(first = 1, second = results.second.dec())

                            resetUIBeforeRetry(tvRetry, ivAction, progressBar)
                            doQuery(pair, uri, item)
                        }
                    }
                }

            ivAction.setOnClickListener {
                bottomSheetLayout?.findViewById<ViewGroup>(R.id.llListFiles)?.removeView(item)
                cancelJob.invoke()
                results = results.copy(second = if (results.second > 0) results.second.dec() else 0)

                if (getUploadCounter() == 0) {
                    resetUploadViews()
                    bsdUploadFiles?.dismiss()
                } else {
                    updateHeader(results.second)
                }
            }

        }
    }

    private fun getUploadCounter() = bottomSheetLayout?.findViewById<ViewGroup>(R.id.llListFiles)?.childCount ?: 0

    private fun resetUploadViews() {
        bottomSheetLayout?.findViewById<ViewGroup>(R.id.llListFiles)?.removeAllViews()
        results = Pair(0,0)
    }

    private fun updateHeader(d: Int) {
        bottomSheetLayout?.findViewById<TextView>(R.id.tvFilesUpload)?.text = getString(R.string.uploaded_files, d, getUploadCounter())
    }

    private fun resetUIBeforeRetry(tvRetry: TextView, ivAction: ImageView, progressBar: ProgressBar) {
        tvRetry.visibility = View.GONE
        ivAction.setImageResource(R.drawable.stop)
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
    }

    private fun writeBitmapToFile(bitmap: Bitmap, file: File, uri: Uri): Int {
        val os = BufferedOutputStream(FileOutputStream(file))
        val mimeType = getMimeType(context!!, uri)
        if (mimeType == "jpg" || mimeType == "jpeg")
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, os)
        else if (mimeType == "png")
            bitmap.compress(Bitmap.CompressFormat.PNG, 70, os)
        os.close()

        return (file.length() / 1024).toInt() / 1024
    }

    private fun getBitmap(uri: Uri): Bitmap = when {
            Build.VERSION.SDK_INT < 28 -> MediaStore.Images.Media.getBitmap(context?.contentResolver, uri)
            else -> {
                val source = ImageDecoder.createSource(context!!.contentResolver, uri)
                ImageDecoder.decodeBitmap(source)
            }
        }

    private fun prepareFilePart(
        file: File,
        uri: Uri,
        progressBar: ProgressBar
    ): MultipartBody.Part {
        val requestFile = ProgressRequestBody(file, getMimeType(context!!, uri), object : UploadCallbacks {
            override fun onProgressUpdate(percentage: Int) {
                progressBar.progress = percentage
            }
        })
        return MultipartBody.Part.createFormData("upload", file.name, requestFile)
    }

    private fun inflateItem(): ViewGroup = layoutInflater.inflate(R.layout.layout_single_file_to_upload, llContent, false) as ViewGroup
}

