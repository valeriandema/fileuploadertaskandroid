package demichev.valerian.fileuploadertaskandroid.network

import android.os.Handler
import android.os.Looper
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.File
import java.io.FileInputStream
import java.io.IOException


class ProgressRequestBody(private val file: File, private val contentType: String, private val listener: UploadCallbacks) : RequestBody() {
    companion object {
        private const val DEFAULT_BUFFER_SIZE = 2048
    }
    override fun contentType(): MediaType? {
        return "$contentType/*".toMediaTypeOrNull()
    }

    @Throws(IOException::class)
    override fun contentLength(): Long {
        return file.length()
    }

    @Throws(IOException::class)
    override fun writeTo(sink: BufferedSink) {
        val fileLength = file.length()
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        val `in` = FileInputStream(file)
        var uploaded: Long = 0
        try {
            var read = 0
            val handler = Handler(Looper.getMainLooper())
            while (`in`.read(buffer).also({ read = it }) != -1) {
                handler.post(ProgressUpdater(listener, uploaded, fileLength))
                uploaded += read.toLong()
                sink.write(buffer, 0, read)
            }
        } finally {
            `in`.close()
        }
    }

    internal class ProgressUpdater(private val listener: UploadCallbacks, private val mUploaded: Long, private val mTotal: Long) : Runnable {
        override fun run() {
            listener.onProgressUpdate((100 * mUploaded / mTotal).toInt())

        }
    }
}


interface UploadCallbacks {
    fun onProgressUpdate(percentage: Int)
}