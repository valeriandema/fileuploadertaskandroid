package demichev.valerian.fileuploadertaskandroid.dagger.repository

import demichev.valerian.fileuploadertaskandroid.dagger.ApplicationScope
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.Response
import retrofit2.Call
import javax.inject.Inject

@ApplicationScope
class RemoteDataSource @Inject constructor(private val remoteService: RemoteService) {
    suspend fun uploadFiles(list: MultipartBody.Part, jsonRequest: RequestBody): retrofit2.Response<Any> = remoteService.uploadFiles(list, jsonRequest)

}