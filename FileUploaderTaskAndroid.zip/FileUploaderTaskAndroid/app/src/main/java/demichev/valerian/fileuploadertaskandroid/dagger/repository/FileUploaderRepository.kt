package demichev.valerian.fileuploadertaskandroid.dagger.repository

import demichev.valerian.fileuploadertaskandroid.dagger.ApplicationScope
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response

@ApplicationScope
interface FileUploaderRepository {
    suspend fun uploadFiles(list: MultipartBody.Part, jsonRequest: RequestBody): Response<Any>
}