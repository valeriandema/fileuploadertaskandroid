package demichev.valerian.fileuploadertaskandroid

import android.app.Application
import demichev.valerian.fileuploadertaskandroid.dagger.AppComponent
import demichev.valerian.fileuploadertaskandroid.dagger.DaggerAppComponent
import demichev.valerian.fileuploadertaskandroid.dagger.RemoteModule

class FileUploaderApplication : Application() {

    companion object {
        lateinit var appComponent: AppComponent
    }

    override fun onCreate() {
        super.onCreate()
        initializeDagger()
    }

    private fun initializeDagger() {
        appComponent = DaggerAppComponent.builder()
            .remoteModule(RemoteModule())
            .build()
    }
}