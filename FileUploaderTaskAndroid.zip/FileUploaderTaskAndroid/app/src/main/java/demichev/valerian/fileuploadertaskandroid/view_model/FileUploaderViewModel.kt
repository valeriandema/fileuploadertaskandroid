package demichev.valerian.fileuploadertaskandroid.view_model

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import demichev.valerian.fileuploadertaskandroid.FileUploaderApplication
import demichev.valerian.fileuploadertaskandroid.dagger.repository.FileUploaderRepoImpl
import kotlinx.coroutines.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import javax.inject.Inject

class FileUploaderViewModel : ViewModel() {
    @Inject
    protected lateinit var apiRequestProvider: FileUploaderRepoImpl
    private var jobs: MutableList<Job>? = null
    val isJobsCleared: MutableLiveData<Boolean>

    init {
        FileUploaderApplication.appComponent.inject(this)
        jobs = arrayListOf()
        isJobsCleared = MutableLiveData()
    }

    fun uploadFiles(list: MultipartBody.Part, jsonRequest: RequestBody, resStatus: (Boolean?) -> Unit): () -> (Unit) {
        val uploaderJob = Job()
        jobs?.add(uploaderJob)

        viewModelScope.launch(CoroutineScope(uploaderJob + Dispatchers.IO).coroutineContext) {
            try {
                val response = apiRequestProvider.uploadFiles(list, jsonRequest)
                withContext(Dispatchers.Main) {
                    if (response.code() == 204) {
                        resStatus.invoke(true)
                    } else {
                        resStatus.invoke(false)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    resStatus.invoke(false)
                }
            } finally {
                if (jobs?.size == 1) {
                    withContext(Dispatchers.Main) {
                        resStatus.invoke(null)
                    }
                }
                uploaderJob.cancel()
                jobs?.remove(uploaderJob)
            }
        }
        val cancelRequest: () -> Unit = {
            uploaderJob.cancel()
            jobs?.remove(uploaderJob)
        }

        return cancelRequest::invoke
    }

    fun clearAllJobs() {
        jobs?.forEach { if (!it.isCancelled) it.cancel() }
        jobs?.clear()
    }

    override fun onCleared() {
        clearAllJobs()
        super.onCleared()
    }
}
