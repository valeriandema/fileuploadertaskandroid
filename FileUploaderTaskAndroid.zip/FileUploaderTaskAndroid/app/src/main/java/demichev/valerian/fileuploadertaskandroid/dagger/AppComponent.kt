package demichev.valerian.fileuploadertaskandroid.dagger

import dagger.Component
import demichev.valerian.fileuploadertaskandroid.view_model.FileUploaderViewModel

@ApplicationScope
@Component(modules = [RemoteModule::class])
interface AppComponent {
    fun inject(viewModel: FileUploaderViewModel)
}