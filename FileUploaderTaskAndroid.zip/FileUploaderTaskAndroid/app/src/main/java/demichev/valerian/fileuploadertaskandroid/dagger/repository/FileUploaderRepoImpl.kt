package demichev.valerian.fileuploadertaskandroid.dagger.repository

import demichev.valerian.fileuploadertaskandroid.dagger.ApplicationScope
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import javax.inject.Inject

@ApplicationScope
class FileUploaderRepoImpl @Inject constructor(private val remoteDataSource: RemoteDataSource) : FileUploaderRepository {
    override suspend fun uploadFiles(list: MultipartBody.Part, jsonRequest: RequestBody): Response<Any> {
        return remoteDataSource.uploadFiles(list, jsonRequest)
    }
}