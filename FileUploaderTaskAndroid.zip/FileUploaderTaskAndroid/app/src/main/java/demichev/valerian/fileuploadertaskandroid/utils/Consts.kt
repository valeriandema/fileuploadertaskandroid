package demichev.valerian.fileuploadertaskandroid.utils

const val MAX_QUANTITY_OF_FILES = 10
const val MAX_SIZE_OF_FILE = 10